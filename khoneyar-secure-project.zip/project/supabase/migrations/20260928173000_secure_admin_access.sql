/*
  Replace the original public CRUD policies with authenticated admin-only writes.

  Bootstrap the manager after deployment:
    1. Create the manager in Supabase Auth.
    2. Copy the user's UUID.
    3. INSERT it into public.admin_users.
*/

create table if not exists public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

alter table public.admin_users enable row level security;

create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.admin_users
    where user_id = auth.uid()
      and active = true
  );
$$;

revoke all on function public.is_admin() from public;
grant execute on function public.is_admin() to anon, authenticated;

alter table public.products enable row level security;

do $$
declare
  policy_record record;
begin
  for policy_record in
    select policyname
    from pg_policies
    where schemaname = 'public' and tablename = 'products'
  loop
    execute format('drop policy if exists %I on public.products', policy_record.policyname);
  end loop;
end $$;

create policy "Public can read products"
on public.products
for select
to anon, authenticated
using (true);

create policy "Admins can insert products"
on public.products
for insert
to authenticated
with check (public.is_admin());

create policy "Admins can update products"
on public.products
for update
to authenticated
using (public.is_admin())
with check (public.is_admin());

create policy "Admins can delete products"
on public.products
for delete
to authenticated
using (public.is_admin());

-- Storage: public read, admin-only writes for this bucket.
insert into storage.buckets (id, name, public)
values ('product-images', 'product-images', true)
on conflict (id) do update set public = true;

drop policy if exists "anon_insert_product_images" on storage.objects;
drop policy if exists "anon_update_product_images" on storage.objects;
drop policy if exists "anon_delete_product_images" on storage.objects;
drop policy if exists "public_read_product_images" on storage.objects;

create policy "Public can read product images"
on storage.objects
for select
to anon, authenticated
using (bucket_id = 'product-images');

create policy "Admins can upload product images"
on storage.objects
for insert
to authenticated
with check (
  bucket_id = 'product-images'
  and (storage.foldername(name))[1] = 'products'
  and public.is_admin()
);

create policy "Admins can update product images"
on storage.objects
for update
to authenticated
using (bucket_id = 'product-images' and public.is_admin())
with check (
  bucket_id = 'product-images'
  and (storage.foldername(name))[1] = 'products'
  and public.is_admin()
);

create policy "Admins can delete product images"
on storage.objects
for delete
to authenticated
using (bucket_id = 'product-images' and public.is_admin());

-- If another permissive storage policy exists, this restrictive guard still
-- prevents non-admin users from writing anything in product-images.
drop policy if exists "Only admins may write product images" on storage.objects;
create policy "Only admins may write product images"
as restrictive
on storage.objects
for all
to authenticated
using (bucket_id <> 'product-images' or public.is_admin())
with check (bucket_id <> 'product-images' or public.is_admin());
