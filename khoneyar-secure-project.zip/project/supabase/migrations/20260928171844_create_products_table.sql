/*
# Create products table for خونه یار store

1. New Tables
- `products`
  - `id` (uuid, primary key)
  - `name` (text, not null) — product name
  - `category` (text, not null) — product category name
  - `short_desc` (text) — short description shown on product card
  - `features` (jsonb, default '[]') — list of product features
  - `price` (bigint, nullable) — price in Toman, null means "call for price"
  - `image` (text) — image URL
  - `badge` (text, nullable) — optional badge label like "محصول جدید"
  - `sort_order` (integer, default 0) — display order, lower shows first
  - `created_at` (timestamptz, default now())
  - `updated_at` (timestamptz, default now())

2. Security
- Enable RLS on `products`.
- Allow anon + authenticated full CRUD — single-tenant store with no auth, data is intentionally public.
- Anyone visiting the site can read products; the admin panel writes as anon too.

3. Notes
- `features` stored as jsonb array of strings.
- `price` is bigint to accommodate large Toman values.
- `sort_order` allows reordering products from the admin panel.
*/

CREATE TABLE IF NOT EXISTS products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  category text NOT NULL,
  short_desc text,
  features jsonb NOT NULL DEFAULT '[]'::jsonb,
  price bigint,
  image text,
  badge text,
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE products ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_products" ON products;
CREATE POLICY "anon_select_products" ON products FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_products" ON products;
CREATE POLICY "anon_insert_products" ON products FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_products" ON products;
CREATE POLICY "anon_update_products" ON products FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_products" ON products;
CREATE POLICY "anon_delete_products" ON products FOR DELETE
  TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_products_sort_order ON products (sort_order);
