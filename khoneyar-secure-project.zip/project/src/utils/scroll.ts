export function scrollToSection(id: string) {
  const el = document.querySelector(id);
  if (!el) return;
  const rect = el.getBoundingClientRect();
  const headerOffset = 80;
  const top = rect.top + window.scrollY - headerOffset;
  window.scrollTo({ top: Math.max(0, top), behavior: 'smooth' });
}
