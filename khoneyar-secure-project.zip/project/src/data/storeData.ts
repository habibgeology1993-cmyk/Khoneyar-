export interface Product {
  id: number;
  name: string;
  slug: string;
  category: string;
  shortDesc: string;
  features: string[];
  price: number | null;
  image: string;
  badge?: string;
}

export interface Category {
  id: number;
  name: string;
  slug: string;
  description: string;
  image: string;
  icon: string;
}

export const categories: Category[] = [
  {
    id: 1,
    name: 'آبسردکن',
    slug: 'water-dispenser',
    description: 'آبسردکن‌های خانگی و گالنی با طراحی مدرن',
    image: 'https://images.pexels.com/photos/38853682/pexels-photo-38853682.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    icon: 'Droplet',
  },
  {
    id: 2,
    name: 'تصفیه آب',
    slug: 'water-purifier',
    description: 'دستگاه‌های تصفیه آب خانگی و اداری با تکنولوژی روز',
    image: 'https://images.pexels.com/photos/20526580/pexels-photo-20526580.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    icon: 'Filter',
  },
  {
    id: 3,
    name: 'بخاری برقی',
    slug: 'electric-heater',
    description: 'بخاری‌های برقی با طراحی ایمن و مصرف بهینه',
    image: 'https://images.pexels.com/photos/6043981/pexels-photo-6043981.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    icon: 'Flame',
  },
  {
    id: 4,
    name: 'کولر',
    slug: 'air-cooler',
    description: 'کولرهای آبی و گازی با قدرت سرمایش بالا',
    image: 'https://images.pexels.com/photos/38788452/pexels-photo-38788452.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    icon: 'Wind',
  },
  {
    id: 5,
    name: 'پنکه',
    slug: 'fan',
    description: 'پنکه‌های ایستاده، رومیزی و سقفی با طراحی زیبا',
    image: 'https://images.pexels.com/photos/10450623/pexels-photo-10450623.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    icon: 'Fan',
  },
  {
    id: 6,
    name: 'شوفاژ برقی',
    slug: 'electric-radiator',
    description: 'شوفاژهای برقی با راندمان بالا و گرمایش یکنواخت',
    image: 'https://images.pexels.com/photos/12034871/pexels-photo-12034871.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    icon: 'ThermometerSun',
  },
];

export const products: Product[] = [
  {
    id: 1,
    name: 'آبسردکن مدل KH-101',
    slug: 'water-dispenser-kh101',
    category: 'آبسردکن',
    shortDesc: 'آبسردکن با ظرفیت مناسب و طراحی شیک',
    features: ['دریچه آب سرد و معتدل', 'موتور کم‌صدا', 'بدنه استیل ضدزنگ', 'گنجایش بالا'],
    price: null,
    image: 'https://images.pexels.com/photos/38853682/pexels-photo-38853682.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    badge: 'محصول جدید',
  },
  {
    id: 2,
    name: 'دستگاه تصفیه آب KH-RO200',
    slug: 'water-purifier-khro200',
    category: 'تصفیه آب',
    shortDesc: 'دستگاه تصفیه آب ۶ مرحله‌ای با فیلتر RO و طراحی جمع‌وجور',
    features: ['فیلتراسیون ۶ مرحله‌ای', 'موتور پرقدرت', 'بدنه فشرده', 'نشانگر تعویض فیلتر'],
    price: null,
    image: 'https://images.pexels.com/photos/20526580/pexels-photo-20526580.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    badge: 'پرفروش',
  },
  {
    id: 3,
    name: 'بخاری برقی KH-H200',
    slug: 'electric-heater-khh200',
    category: 'بخاری برقی',
    shortDesc: 'بخاری برقی با سیستم ایمنی و گرمایش سریع',
    features: ['ترموستات قابل تنظیم', 'سیستم قطع خودکار', 'بدنه خنک‌کننده', 'حفاظ از کودک'],
    price: null,
    image: 'https://images.pexels.com/photos/6043981/pexels-photo-6043981.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  },
  {
    id: 4,
    name: 'کولر آبی KH-AC300',
    slug: 'air-cooler-khac300',
    category: 'کولر',
    shortDesc: 'کولر آبی با پد سلولزی و موتور کم‌مصرف',
    features: ['پد سلولزی ضخیم', 'موتور دوبل', 'مخزن بزرگ', 'چرخ‌های متحرک'],
    price: null,
    image: 'https://images.pexels.com/photos/38788452/pexels-photo-38788452.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  },
  {
    id: 5,
    name: 'پنکه ایستاده KH-F150',
    slug: 'fan-khf150',
    category: 'پنکه',
    shortDesc: 'پنکه ایستاده با سرعت قابل تنظیم و طراحی مدرن',
    features: ['سه سرعت قابل تنظیم', 'تیغه بزرگ', 'قابل تنظیم ارتفاع', 'موتور بی‌صدا'],
    price: null,
    image: 'https://images.pexels.com/photos/10450623/pexels-photo-10450623.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  },
  {
    id: 6,
    name: 'شوفاژ برقی KH-R500',
    slug: 'electric-radiator-khr500',
    category: 'شوفاژ برقی',
    shortDesc: 'شوفاژ برقی با المان روغنی و گرمایش یکنواخت',
    features: ['المان روغنی', 'ترموستات هوشمند', 'چرخ‌های متحرک', 'قطع خودکار ایمنی'],
    price: null,
    image: 'https://images.pexels.com/photos/12034871/pexels-photo-12034871.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    badge: 'ویژه',
  },
];

export const advantages = [
  { icon: 'ShieldCheck', title: 'تضمین اصالت کالا', description: 'تمامی محصولات اصل و معتبر هستند' },
  { icon: 'BadgeCheck', title: 'گارانتی', description: 'محصولات دارای گارانتی و خدمات پس از فروش' },
  { icon: 'Truck', title: 'ارسال به سراسر کشور', description: 'ارسال سریع و مطمئن به تمامی نقاط ایران' },
  { icon: 'Headphones', title: 'مشاوره قبل از خرید', description: 'کارشناسان ما برای راهنمایی در کنار شما هستند' },
  { icon: 'Zap', title: 'تحویل سریع', description: 'پردازش و ارسال سفارش در کوتاه‌ترین زمان' },
  { icon: 'PhoneCall', title: 'پشتیبانی فروش', description: 'پاسخگویی به سوالات و پیگیری سفارش‌ها' },
];

export const contactInfo = {
  phone: '02133514761',
  mobile: '09199983073',
  address: 'تهران، امین حضور، پاساژ محمد، طبقه ۲، پلاک ۳۳',
  instagram: 'khoneyar',
  telegram: 'khoneyar',
  whatsapp: 'khoneyar',
};

export const navLinks = [
  { label: 'صفحه اصلی', href: '#home' },
  { label: 'محصولات', href: '#products' },
  { label: 'دسته‌بندی‌ها', href: '#categories' },
  { label: 'درباره ما', href: '#about' },
  { label: 'تماس با ما', href: '#contact' },
];
