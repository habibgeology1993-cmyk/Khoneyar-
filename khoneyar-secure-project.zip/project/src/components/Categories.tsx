import { Droplet, Filter, Flame, Wind, Fan, ThermometerSun, ArrowLeft } from 'lucide-react';
import { categories } from '@/data/storeData';
import { scrollToSection } from '@/utils/scroll';

const iconMap: Record<string, React.ComponentType<{ className?: string; strokeWidth?: number }>> = {
  Droplet,
  Filter,
  Flame,
  Wind,
  Fan,
  ThermometerSun,
};

export default function Categories() {
  return (
    <section id="categories" className="py-12 sm:py-16 lg:py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8 sm:mb-12">
          <h2 className="text-xl sm:text-2xl lg:text-3xl font-extrabold text-slate-800 mb-2 sm:mb-3">
            دسته‌بندی محصولات
          </h2>
          <p className="text-sm sm:text-base text-slate-500">
            محصولات متنوع خونه یار برای نیازهای مختلف خانه شما
          </p>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4 lg:gap-5">
          {categories.map((cat, idx) => {
            const Icon = iconMap[cat.icon] ?? Droplet;
            return (
              <button
                key={cat.id}
                className="group relative overflow-hidden rounded-2xl bg-slate-50 hover:bg-white border border-slate-100 hover:border-brand-200 hover:shadow-xl hover:shadow-brand-900/5 transition-all duration-300 animate-fade-in-up"
                style={{ animationDelay: `${idx * 0.05}s` }}
              >
                <div className="aspect-square overflow-hidden">
                  <img
                    src={cat.image}
                    alt={cat.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    loading="lazy"
                  />
                </div>
                <div className="absolute inset-0 bg-gradient-to-t from-slate-900/70 via-slate-900/20 to-transparent" />
                <div className="absolute bottom-0 right-0 left-0 p-3 sm:p-4 text-center">
                  <div className="inline-flex w-8 h-8 sm:w-10 sm:h-10 items-center justify-center rounded-lg bg-white/90 backdrop-blur-sm mb-1.5 sm:mb-2 group-hover:bg-brand-600 transition-colors duration-300">
                    <Icon className="w-4 h-4 sm:w-5 sm:h-5 text-brand-600 group-hover:text-white transition-colors duration-300" strokeWidth={2} />
                  </div>
                  <h3 className="text-xs sm:text-sm font-bold text-white">{cat.name}</h3>
                </div>
              </button>
            );
          })}
        </div>

        <div className="text-center mt-8 sm:mt-10">
          <button
            onClick={() => scrollToSection('#products')}
            className="inline-flex items-center gap-2 text-sm font-semibold text-brand-600 hover:text-brand-700 group"
          >
            مشاهده همه محصولات
            <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
          </button>
        </div>
      </div>
    </section>
  );
}
