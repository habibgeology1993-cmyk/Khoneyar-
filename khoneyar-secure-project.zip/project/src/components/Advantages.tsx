import { ShieldCheck, BadgeCheck, Truck, Headphones, Zap, PhoneCall } from 'lucide-react';
import { advantages } from '@/data/storeData';

const iconMap: Record<string, React.ComponentType<{ className?: string; strokeWidth?: number }>> = {
  ShieldCheck,
  BadgeCheck,
  Truck,
  Headphones,
  Zap,
  PhoneCall,
};

export default function Advantages() {
  return (
    <section className="py-12 sm:py-16 lg:py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8 sm:mb-12">
          <h2 className="text-xl sm:text-2xl lg:text-3xl font-extrabold text-slate-800 mb-2 sm:mb-3">
            مزیت‌های خونه یار
          </h2>
          <p className="text-sm sm:text-base text-slate-500">
            چرا خرید از خونه یار راحت و مطمئن است
          </p>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4 lg:gap-5">
          {advantages.map((adv, idx) => {
            const Icon = iconMap[adv.icon] ?? ShieldCheck;
            return (
              <div
                key={idx}
                className="group flex items-start gap-3 sm:gap-4 p-4 sm:p-5 lg:p-6 bg-slate-50 hover:bg-brand-50 rounded-2xl border border-slate-100 hover:border-brand-200 transition-all duration-300 animate-fade-in-up"
                style={{ animationDelay: `${idx * 0.06}s` }}
              >
                <div className="flex-shrink-0 w-11 h-11 sm:w-12 sm:h-12 lg:w-14 lg:h-14 rounded-xl bg-white group-hover:bg-brand-600 flex items-center justify-center shadow-sm transition-colors duration-300">
                  <Icon className="w-5 h-5 sm:w-6 sm:h-6 text-brand-600 group-hover:text-white transition-colors duration-300" strokeWidth={2} />
                </div>
                <div>
                  <h3 className="text-sm sm:text-base font-bold text-slate-800 mb-1">
                    {adv.title}
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-500 leading-relaxed">
                    {adv.description}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
