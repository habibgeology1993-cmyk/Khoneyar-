import { useState, useEffect } from 'react';
import { Phone, Eye, Check, Tag, Loader2, AlertCircle } from 'lucide-react';
import { supabase, type ProductRow } from '@/lib/supabase';
import { contactInfo } from '@/data/storeData';

function ProductCard({ product }: { product: ProductRow }) {
  return (
    <div className="group bg-white rounded-2xl border border-slate-100 hover:border-brand-200 overflow-hidden hover:shadow-xl hover:shadow-brand-900/5 transition-all duration-300 flex flex-col">
      <div className="relative aspect-[4/3] overflow-hidden bg-slate-50">
        {product.image ? (
          <img
            src={product.image}
            alt={product.name}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            loading="lazy"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-slate-100">
            <Tag className="w-10 h-10 text-slate-300" />
          </div>
        )}
        {product.badge && (
          <div className="absolute top-3 right-3 px-3 py-1 bg-accent-500 text-white text-[11px] font-semibold rounded-full shadow-md">
            {product.badge}
          </div>
        )}
      </div>

      <div className="flex flex-col flex-1 p-4 sm:p-5">
        <div className="mb-2">
          <span className="inline-block text-[11px] font-medium text-brand-600 bg-brand-50 px-2.5 py-0.5 rounded-md">
            {product.category}
          </span>
        </div>

        <h3 className="text-sm sm:text-base font-bold text-slate-800 mb-2 leading-snug">
          {product.name}
        </h3>

        {product.short_desc && (
          <p className="text-xs sm:text-sm text-slate-500 mb-3 leading-relaxed">
            {product.short_desc}
          </p>
        )}

        {product.features && product.features.length > 0 && (
          <ul className="space-y-1.5 mb-4 flex-1">
            {product.features.map((feat, i) => (
              <li key={i} className="flex items-center gap-2 text-xs text-slate-600">
                <Check className="w-3.5 h-3.5 text-brand-500 flex-shrink-0" strokeWidth={2.5} />
                <span>{feat}</span>
              </li>
            ))}
          </ul>
        )}

        <div className="mb-4">
          {product.price ? (
            <div className="flex items-center gap-2">
              <Tag className="w-4 h-4 text-slate-400" />
              <span className="text-base font-extrabold text-slate-800">
                {product.price.toLocaleString('fa-IR')}
                <span className="text-xs font-medium text-slate-500 mr-1">تومان</span>
              </span>
            </div>
          ) : (
            <div className="px-3 py-2 bg-slate-50 rounded-lg text-center">
              <span className="text-xs font-medium text-slate-600">
                برای اطلاع از قیمت تماس بگیرید
              </span>
            </div>
          )}
        </div>

        <div className="flex gap-2">
          <button className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-lg transition-colors">
            <Eye className="w-3.5 h-3.5" />
            مشاهده محصول
          </button>
          <a
            href={`tel:${contactInfo.phone}`}
            className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2.5 bg-brand-600 hover:bg-brand-700 text-white text-xs font-semibold rounded-lg transition-colors shadow-sm"
          >
            <Phone className="w-3.5 h-3.5" />
            تماس برای خرید
          </a>
        </div>
      </div>
    </div>
  );
}

export default function FeaturedProducts() {
  const [products, setProducts] = useState<ProductRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;

    async function load() {
      setLoading(true);
      setError(null);
      const { data, error } = await supabase
        .from('products')
        .select('*')
        .order('sort_order', { ascending: true });

      if (cancelled) return;

      if (error) {
        setError('خطا در بارگذاری محصولات');
      } else {
        setProducts((data as ProductRow[]) ?? []);
      }
      setLoading(false);
    }

    load();

    return () => {
      cancelled = true;
    };
  }, []);

  return (
    <section id="products" className="py-12 sm:py-16 lg:py-20 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8 sm:mb-12">
          <h2 className="text-xl sm:text-2xl lg:text-3xl font-extrabold text-slate-800 mb-2 sm:mb-3">
            محصولات ویژه
          </h2>
          <p className="text-sm sm:text-base text-slate-500">
            منتخبی از محصولات باکیفیت خونه یار
          </p>
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-16">
            <Loader2 className="w-8 h-8 text-brand-500 animate-spin" />
          </div>
        ) : error ? (
          <div className="flex flex-col items-center justify-center py-16 gap-3">
            <AlertCircle className="w-8 h-8 text-red-400" />
            <p className="text-sm text-slate-500">{error}</p>
          </div>
        ) : products.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16">
            <p className="text-sm text-slate-500">هنوز محصولی ثبت نشده است.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-5 lg:gap-6">
            {products.map((product, idx) => (
              <div
                key={product.id}
                className="animate-fade-in-up"
                style={{ animationDelay: `${idx * 0.08}s` }}
              >
                <ProductCard product={product} />
              </div>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
