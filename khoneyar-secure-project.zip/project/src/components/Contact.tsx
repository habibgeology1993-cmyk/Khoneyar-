import { Phone, Smartphone, MapPin, Clock, MessageCircle } from 'lucide-react';
import { contactInfo } from '@/data/storeData';

export default function Contact() {
  return (
    <section id="contact" className="py-12 sm:py-16 lg:py-20 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8 sm:mb-12">
          <h2 className="text-xl sm:text-2xl lg:text-3xl font-extrabold text-slate-800 mb-2 sm:mb-3">
            تماس با فروشگاه
          </h2>
          <p className="text-sm sm:text-base text-slate-500">
            برای سفارش یا مشاوره با ما در ارتباط باشید
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 lg:gap-5 mb-8">
          {/* Phone */}
          <div className="bg-white rounded-2xl border border-slate-100 p-5 sm:p-6 text-center hover:shadow-lg transition-shadow">
            <div className="inline-flex w-12 h-12 sm:w-14 sm:h-14 items-center justify-center rounded-xl bg-brand-100 mb-3">
              <Phone className="w-5 h-5 sm:w-6 sm:h-6 text-brand-600" strokeWidth={2} />
            </div>
            <h3 className="text-sm font-bold text-slate-800 mb-1">شماره فروشگاه</h3>
            <a
              href={`tel:${contactInfo.phone}`}
              className="text-base font-extrabold text-brand-600 hover:text-brand-700 transition-colors persian-num"
              dir="ltr"
            >
              {contactInfo.phone}
            </a>
          </div>

          {/* Mobile */}
          <div className="bg-white rounded-2xl border border-slate-100 p-5 sm:p-6 text-center hover:shadow-lg transition-shadow">
            <div className="inline-flex w-12 h-12 sm:w-14 sm:h-14 items-center justify-center rounded-xl bg-brand-100 mb-3">
              <Smartphone className="w-5 h-5 sm:w-6 sm:h-6 text-brand-600" strokeWidth={2} />
            </div>
            <h3 className="text-sm font-bold text-slate-800 mb-1">شماره همراه</h3>
            <a
              href={`tel:${contactInfo.mobile}`}
              className="text-base font-extrabold text-brand-600 hover:text-brand-700 transition-colors persian-num"
              dir="ltr"
            >
              {contactInfo.mobile}
            </a>
          </div>

          {/* Address */}
          <div className="bg-white rounded-2xl border border-slate-100 p-5 sm:p-6 text-center hover:shadow-lg transition-shadow">
            <div className="inline-flex w-12 h-12 sm:w-14 sm:h-14 items-center justify-center rounded-xl bg-brand-100 mb-3">
              <MapPin className="w-5 h-5 sm:w-6 sm:h-6 text-brand-600" strokeWidth={2} />
            </div>
            <h3 className="text-sm font-bold text-slate-800 mb-1">آدرس</h3>
            <p className="text-xs text-slate-500 leading-relaxed">{contactInfo.address}</p>
          </div>

          {/* Hours */}
          <div className="bg-white rounded-2xl border border-slate-100 p-5 sm:p-6 text-center hover:shadow-lg transition-shadow">
            <div className="inline-flex w-12 h-12 sm:w-14 sm:h-14 items-center justify-center rounded-xl bg-brand-100 mb-3">
              <Clock className="w-5 h-5 sm:w-6 sm:h-6 text-brand-600" strokeWidth={2} />
            </div>
            <h3 className="text-sm font-bold text-slate-800 mb-1">ساعات کاری</h3>
            <p className="text-xs text-slate-500 leading-relaxed">شنبه تا پنجشنبه<br />۹ تا ۱۸</p>
          </div>
        </div>

        {/* Direct call buttons */}
        <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 justify-center max-w-2xl mx-auto">
          <a
            href={`tel:${contactInfo.phone}`}
            className="flex items-center justify-center gap-2 px-6 py-4 bg-brand-600 hover:bg-brand-700 text-white text-sm font-semibold rounded-xl transition-all shadow-lg shadow-brand-500/25 hover:shadow-xl hover:-translate-y-0.5"
          >
            <Phone className="w-5 h-5" />
            تماس مستقیم با فروشگاه
          </a>
          <a
            href={`https://wa.me/98${contactInfo.mobile.slice(1)}`}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center gap-2 px-6 py-4 bg-white hover:bg-slate-50 text-slate-700 text-sm font-semibold rounded-xl border-2 border-slate-200 hover:border-brand-300 transition-all"
          >
            <MessageCircle className="w-5 h-5 text-brand-600" />
            پیام در واتساپ
          </a>
        </div>
      </div>
    </section>
  );
}
