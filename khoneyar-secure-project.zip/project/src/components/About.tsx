import { Home, CheckCircle2 } from 'lucide-react';

export default function About() {
  return (
    <section id="about" className="py-12 sm:py-16 lg:py-20 bg-gradient-to-b from-brand-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-8 lg:gap-12 items-center">
          {/* Image */}
          <div className="relative order-2 lg:order-1">
            <div className="relative aspect-[4/3] rounded-3xl overflow-hidden shadow-2xl shadow-brand-900/10">
              <img
                src="https://images.pexels.com/photos/6636288/pexels-photo-6636288.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
                alt="درباره خونه یار"
                className="w-full h-full object-cover"
                loading="lazy"
              />
            </div>
            <div className="absolute -top-4 -left-4 sm:-top-6 sm:-left-6 bg-white rounded-2xl shadow-xl p-4 sm:p-5">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-brand-100 flex items-center justify-center">
                  <Home className="w-5 h-5 sm:w-6 sm:h-6 text-brand-600" strokeWidth={2.5} />
                </div>
                <div>
                  <p className="text-lg sm:text-2xl font-extrabold text-slate-800">+۱۰۰</p>
                  <p className="text-[10px] sm:text-xs text-slate-500">محصول متنوع</p>
                </div>
              </div>
            </div>
          </div>

          {/* Text */}
          <div className="order-1 lg:order-2 text-center lg:text-right">
            <h2 className="text-xl sm:text-2xl lg:text-3xl font-extrabold text-slate-800 mb-4 sm:mb-6">
              چرا خونه یار؟
            </h2>

            <p className="text-sm sm:text-base text-slate-600 leading-relaxed mb-4 sm:mb-6">
              خونه یار با هدف ساده‌سازی خرید لوازم سرمایشی و گرمایشی و تصفیه آب برای خانواده‌های ایرانی فعالیت می‌کند. ما با تمرکز بر ارائه محصولات باکیفیت و خدمات صادقانه، تلاش می‌کنیم تجربه‌ای مطمئن برای مشتریان فراهم کنیم.
            </p>

            <p className="text-sm sm:text-base text-slate-600 leading-relaxed mb-6 sm:mb-8">
              تیم خونه یار پیش از فروش، در انتخاب محصول مناسب کنار شماست و پس از فروش، با پشتیبانی و خدمات خود پاسخگوی نیازهای شماست. هدف ما رضایت شماست.
            </p>

            <div className="grid grid-cols-2 gap-3 sm:gap-4">
              {[
                'مشاوره تخصصی قبل از خرید',
                'محصولات اصل و معتبر',
                'پشتیبانی پس از فروش',
                'ارسال به سراسر کشور',
              ].map((item, i) => (
                <div key={i} className="flex items-center gap-2 text-right">
                  <CheckCircle2 className="w-4 h-4 sm:w-5 sm:h-5 text-brand-600 flex-shrink-0" strokeWidth={2.5} />
                  <span className="text-xs sm:text-sm font-medium text-slate-700">{item}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
