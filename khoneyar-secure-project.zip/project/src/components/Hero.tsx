import { ArrowLeft, Phone, Sparkles } from 'lucide-react';
import { contactInfo } from '@/data/storeData';
import { scrollToSection } from '@/utils/scroll';

export default function Hero() {
  const scrollTo = (id: string) => {
    scrollToSection(id);
  };

  return (
    <section id="home" className="relative overflow-hidden bg-gradient-to-br from-brand-50 via-white to-brand-50">
      {/* Decorative shapes */}
      <div className="absolute top-0 left-0 w-72 h-72 bg-brand-200/30 rounded-full blur-3xl -translate-x-1/3 -translate-y-1/3" />
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-brand-100/40 rounded-full blur-3xl translate-x-1/3 translate-y-1/3" />
      <div className="absolute top-1/2 left-1/2 w-64 h-64 bg-accent-100/20 rounded-full blur-3xl" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16 lg:py-24">
        <div className="grid lg:grid-cols-2 gap-8 lg:gap-12 items-center">
          {/* Text */}
          <div className="text-center lg:text-right animate-fade-in-up">
            <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-brand-100 text-brand-700 rounded-full text-xs sm:text-sm font-medium mb-4 sm:mb-6">
              <Sparkles className="w-3.5 h-3.5" />
              <span>فروشگاه اینترنتی لوازم خانگی</span>
            </div>

            <h2 className="text-2xl sm:text-3xl lg:text-5xl font-extrabold text-slate-800 leading-tight mb-4 sm:mb-6">
              خونه یار؛ انتخاب مطمئن
              <br />
              <span className="text-brand-600">برای خانه شما</span>
            </h2>

            <p className="text-sm sm:text-base lg:text-lg text-slate-600 leading-relaxed mb-6 sm:mb-8 max-w-xl mx-auto lg:mx-0">
              آبسردکن، تصفیه آب و لوازم سرمایشی و گرمایشی با کیفیت و قیمت مناسب
            </p>

            <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 justify-center lg:justify-start">
              <button
                onClick={() => scrollTo('#products')}
                className="group flex items-center justify-center gap-2 px-6 py-3.5 bg-brand-600 hover:bg-brand-700 text-white text-sm font-semibold rounded-xl transition-all duration-200 shadow-lg shadow-brand-500/25 hover:shadow-xl hover:shadow-brand-500/30 hover:-translate-y-0.5"
              >
                مشاهده محصولات
                <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
              </button>

              <a
                href={`tel:${contactInfo.phone}`}
                className="flex items-center justify-center gap-2 px-6 py-3.5 bg-white hover:bg-slate-50 text-brand-700 text-sm font-semibold rounded-xl border-2 border-brand-200 hover:border-brand-300 transition-all duration-200"
              >
                <Phone className="w-4 h-4" />
                تماس با فروشگاه
              </a>
            </div>
          </div>

          {/* Image */}
          <div className="relative animate-fade-in-up" style={{ animationDelay: '0.15s' }}>
            <div className="relative aspect-[4/3] rounded-3xl overflow-hidden shadow-2xl shadow-brand-900/15">
              <img
                src="https://images.pexels.com/photos/7535073/pexels-photo-7535073.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
                alt="خونه یار فروشگاه لوازم خانگی"
                className="w-full h-full object-cover"
                loading="eager"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-brand-900/20 to-transparent" />
            </div>

            {/* Floating card */}
            <div className="absolute -bottom-4 -right-4 sm:-bottom-6 sm:-right-6 bg-white rounded-2xl shadow-xl p-4 sm:p-5 max-w-[200px]">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-accent-100 flex items-center justify-center">
                  <Sparkles className="w-5 h-5 sm:w-6 sm:h-6 text-accent-600" />
                </div>
                <div>
                  <p className="text-xs sm:text-sm font-bold text-slate-800">کیفیت تضمینی</p>
                  <p className="text-[10px] sm:text-xs text-slate-500">اصالت و گارانتی</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
