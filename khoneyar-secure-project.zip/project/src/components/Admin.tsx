import { useState, useEffect, useCallback, type FormEvent } from 'react';
import {
  Plus, Edit2, Trash2, X, Save, ArrowUp, ArrowDown, Loader2,
  AlertCircle, Upload, Phone, Eye, Check, Tag, Package, LogOut, ShieldCheck,
} from 'lucide-react';
import { supabase, type ProductRow } from '@/lib/supabase';
import { contactInfo, categories } from '@/data/storeData';

interface EditForm {
  name: string;
  category: string;
  short_desc: string;
  features: string;
  price: string;
  image: string;
  badge: string;
}

const emptyForm: EditForm = {
  name: '',
  category: categories[0]?.name ?? '',
  short_desc: '',
  features: '',
  price: '',
  image: '',
  badge: '',
};

export default function Admin() {
  const [session, setSession] = useState<Awaited<ReturnType<typeof supabase.auth.getSession>>['data']['session']>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [isAuthorized, setIsAuthorized] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [signingIn, setSigningIn] = useState(false);
  const [products, setProducts] = useState<ProductRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState<EditForm>(emptyForm);
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  useEffect(() => {
    let mounted = true;
    supabase.auth.getSession().then(async ({ data }) => {
      if (!mounted) return;
      setSession(data.session);
      if (!data.session) {
        setIsAuthorized(false);
        setAuthLoading(false);
        return;
      }
      const { data: admin, error } = await supabase.rpc('is_admin');
      if (mounted) {
        setIsAuthorized(Boolean(admin) && !error);
        setAuthLoading(false);
      }
    });

    const { data: listener } = supabase.auth.onAuthStateChange((_event, nextSession) => {
      if (!mounted) return;
      setSession(nextSession);
      if (!nextSession) {
        setIsAuthorized(false);
        setAuthLoading(false);
        return;
      }
      void supabase.rpc('is_admin').then(({ data, error }) => {
        if (mounted) {
          setIsAuthorized(Boolean(data) && !error);
          setAuthLoading(false);
        }
      });
    });

    return () => {
      mounted = false;
      listener.subscription.unsubscribe();
    };
  }, []);

  const handleSignIn = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setAuthError(null);
    setSigningIn(true);
    const { error } = await supabase.auth.signInWithPassword({
      email: email.trim(),
      password,
    });
    if (error) setAuthError('ایمیل یا رمز عبور صحیح نیست.');
    setSigningIn(false);
  };

  const handleSignOut = async () => {
    await supabase.auth.signOut();
  };

  const loadProducts = useCallback(async () => {
    if (!session) return;
    setLoading(true);
    setError(null);
    const { data, error } = await supabase
      .from('products')
      .select('*')
      .order('sort_order', { ascending: true });

    if (error) {
      setError('خطا در بارگذاری محصولات');
    } else {
      setProducts((data as ProductRow[]) ?? []);
    }
    setLoading(false);
  }, [session]);

  useEffect(() => {
    if (session) loadProducts();
  }, [session, loadProducts]);

  const openAddForm = () => {
    setEditingId(null);
    setForm(emptyForm);
    setFormError(null);
    setShowForm(true);
  };

  const openEditForm = (p: ProductRow) => {
    setEditingId(p.id);
    setForm({
      name: p.name,
      category: p.category,
      short_desc: p.short_desc ?? '',
      features: Array.isArray(p.features) ? p.features.join('\n') : '',
      price: p.price != null ? String(p.price) : '',
      image: p.image ?? '',
      badge: p.badge ?? '',
    });
    setFormError(null);
    setShowForm(true);
  };

  const closeForm = () => {
    setShowForm(false);
    setEditingId(null);
    setForm(emptyForm);
    setFormError(null);
  };

  const handleSave = async () => {
    if (!form.name.trim()) {
      setFormError('نام محصول الزامی است');
      return;
    }
    if (!form.category.trim()) {
      setFormError('دسته‌بندی محصول الزامی است');
      return;
    }

    setSaving(true);
    setFormError(null);

    const featuresArray = form.features
      .split('\n')
      .map((f) => f.trim())
      .filter((f) => f.length > 0);

    const priceNum = form.price.trim() ? parseInt(form.price.replace(/[^0-9]/g, ''), 10) : null;
    const payload = {
      name: form.name.trim(),
      category: form.category.trim(),
      short_desc: form.short_desc.trim() || null,
      features: featuresArray,
      price: priceNum != null && !isNaN(priceNum) ? priceNum : null,
      image: form.image.trim() || null,
      badge: form.badge.trim() || null,
    };

    if (editingId) {
      const { error } = await supabase
        .from('products')
        .update(payload)
        .eq('id', editingId);
      if (error) {
        setFormError('خطا در ذخیره تغییرات');
        setSaving(false);
        return;
      }
    } else {
      const maxSort = products.length > 0
        ? Math.max(...products.map((p) => p.sort_order))
        : 0;
      const { error } = await supabase
        .from('products')
        .insert({ ...payload, sort_order: maxSort + 1 });
      if (error) {
        setFormError('خطا در افزودن محصول');
        setSaving(false);
        return;
      }
    }

    setSaving(false);
    closeForm();
    await loadProducts();
  };

  const handleDelete = async (id: string) => {
    if (!confirm('آیا از حذف این محصول مطمئن هستید؟')) return;
    const { error } = await supabase.from('products').delete().eq('id', id);
    if (error) {
      setError('خطا در حذف محصول');
      return;
    }
    await loadProducts();
  };

  const moveProduct = async (index: number, direction: 'up' | 'down') => {
    if (direction === 'up' && index === 0) return;
    if (direction === 'down' && index === products.length - 1) return;

    const swapIndex = direction === 'up' ? index - 1 : index + 1;
    const productA = products[index];
    const productB = products[swapIndex];

    const updates = [
      { id: productA.id, sort_order: productB.sort_order },
      { id: productB.id, sort_order: productA.sort_order },
    ];

    for (const u of updates) {
      const { error } = await supabase
        .from('products')
        .update({ sort_order: u.sort_order })
        .eq('id', u.id);
      if (error) {
        setError('خطا در تغییر ترتیب محصولات');
        return;
      }
    }

    await loadProducts();
  };

  const handleImageUpload = async (file: File) => {
    setFormError(null);
    const allowedTypes = new Set(['image/jpeg', 'image/png', 'image/webp']);
    if (!allowedTypes.has(file.type)) {
      setFormError('فقط تصویر JPG، PNG یا WebP مجاز است');
      return;
    }
    if (file.size > 2 * 1024 * 1024) {
      setFormError('حجم تصویر نباید بیشتر از ۲ مگابایت باشد');
      return;
    }

    const extensionByType: Record<string, string> = {
      'image/jpeg': 'jpg',
      'image/png': 'png',
      'image/webp': 'webp',
    };
    const fileName = `${crypto.randomUUID()}.${extensionByType[file.type]}`;
    const filePath = `products/${fileName}`;

    const { error: uploadError } = await supabase.storage
      .from('product-images')
      .upload(filePath, file);

    if (uploadError) {
      setFormError('خطا در آپلود تصویر. لطفاً آدرس تصویر را دستی وارد کنید.');
      return;
    }

    const { data: urlData } = supabase.storage
      .from('product-images')
      .getPublicUrl(filePath);

    if (urlData?.publicUrl) {
      setForm((prev) => ({ ...prev, image: urlData.publicUrl }));
    }
  };

  if (authLoading) {
    return (
      <section className="min-h-screen bg-slate-50 flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-brand-500 animate-spin" />
      </section>
    );
  }

  if (!session) {
    return (
      <section className="min-h-screen bg-slate-50 flex items-center justify-center px-4">
        <form onSubmit={handleSignIn} className="w-full max-w-md bg-white rounded-2xl border border-slate-100 shadow-xl p-6 sm:p-8" dir="rtl">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-11 h-11 rounded-xl bg-brand-50 flex items-center justify-center">
              <ShieldCheck className="w-6 h-6 text-brand-600" />
            </div>
            <div>
              <h1 className="text-xl font-extrabold text-slate-800">ورود مدیر</h1>
              <p className="text-xs text-slate-500 mt-1">برای ورود به پنل، حساب مجاز مدیر لازم است.</p>
            </div>
          </div>

          {authError && (
            <div className="mb-4 flex items-center gap-2 px-3 py-2.5 bg-red-50 text-red-600 rounded-lg text-sm">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              {authError}
            </div>
          )}

          <label className="block text-sm font-medium text-slate-700 mb-1.5">ایمیل</label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            autoComplete="username"
            required
            className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-brand-500 mb-4"
            dir="ltr"
          />

          <label className="block text-sm font-medium text-slate-700 mb-1.5">رمز عبور</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            autoComplete="current-password"
            required
            minLength={8}
            className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-brand-500 mb-5"
            dir="ltr"
          />

          <button
            type="submit"
            disabled={signingIn}
            className="w-full flex items-center justify-center gap-2 px-4 py-2.5 bg-brand-600 hover:bg-brand-700 text-white text-sm font-semibold rounded-lg transition-colors disabled:opacity-50"
          >
            {signingIn && <Loader2 className="w-4 h-4 animate-spin" />}
            ورود امن
          </button>
        </form>
      </section>
    );
  }

  if (!isAuthorized) {
    return (
      <section className="min-h-screen bg-slate-50 flex items-center justify-center px-4">
        <div className="w-full max-w-md bg-white rounded-2xl border border-slate-100 shadow-xl p-6 sm:p-8 text-center" dir="rtl">
          <ShieldCheck className="w-10 h-10 text-red-500 mx-auto mb-4" />
          <h1 className="text-xl font-extrabold text-slate-800">دسترسی مجاز نیست</h1>
          <p className="text-sm text-slate-500 mt-2 mb-6">این حساب واردشده در فهرست مدیران پنل ثبت نشده است.</p>
          <button
            onClick={handleSignOut}
            className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-sm font-semibold rounded-lg"
          >
            خروج از حساب
          </button>
        </div>
      </section>
    );
  }

  return (
    <section id="admin" className="min-h-screen bg-slate-50 pt-20 pb-12">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
          <div>
            <h2 className="text-xl sm:text-2xl font-extrabold text-slate-800 flex items-center gap-2">
              <Package className="w-6 h-6 text-brand-600" />
              مدیریت محصولات
            </h2>
            <p className="text-sm text-slate-500 mt-1">
              محصولات فروشگاه خونه یار را اینجا مدیریت کنید
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handleSignOut}
              className="flex items-center gap-2 px-3 py-2.5 bg-white hover:bg-slate-100 text-slate-600 text-sm font-semibold rounded-lg border border-slate-200 transition-colors"
            >
              <LogOut className="w-4 h-4" />
              خروج
            </button>
            <button
              onClick={openAddForm}
              className="flex items-center gap-2 px-4 py-2.5 bg-brand-600 hover:bg-brand-700 text-white text-sm font-semibold rounded-lg transition-colors shadow-md shadow-brand-500/20"
            >
              <Plus className="w-4 h-4" />
              افزودن محصول جدید
            </button>
          </div>
        </div>

        {error && (
          <div className="mb-4 flex items-center gap-2 px-4 py-3 bg-red-50 text-red-600 rounded-lg text-sm">
            <AlertCircle className="w-5 h-5 flex-shrink-0" />
            {error}
          </div>
        )}

        {/* Loading */}
        {loading ? (
          <div className="flex items-center justify-center py-16">
            <Loader2 className="w-8 h-8 text-brand-500 animate-spin" />
          </div>
        ) : products.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 gap-3">
            <Package className="w-12 h-12 text-slate-300" />
            <p className="text-sm text-slate-500">هنوز محصولی ثبت نشده است.</p>
            <button
              onClick={openAddForm}
              className="flex items-center gap-2 px-4 py-2 bg-brand-600 text-white text-sm font-semibold rounded-lg mt-2"
            >
              <Plus className="w-4 h-4" />
              افزودن اولین محصول
            </button>
          </div>
        ) : (
          /* Product List */
          <div className="space-y-3">
            {products.map((p, idx) => (
              <div
                key={p.id}
                className="flex items-center gap-3 sm:gap-4 bg-white rounded-xl border border-slate-100 p-3 sm:p-4 hover:shadow-md transition-shadow"
              >
                {/* Image */}
                <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-lg overflow-hidden bg-slate-100 flex-shrink-0">
                  {p.image ? (
                    <img src={p.image} alt={p.name} className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      <Tag className="w-6 h-6 text-slate-300" />
                    </div>
                  )}
                </div>

                {/* Info */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-[10px] font-medium text-brand-600 bg-brand-50 px-2 py-0.5 rounded">
                      {p.category}
                    </span>
                    {p.badge && (
                      <span className="text-[10px] font-medium text-accent-700 bg-accent-50 px-2 py-0.5 rounded">
                        {p.badge}
                      </span>
                    )}
                  </div>
                  <h3 className="text-sm font-bold text-slate-800 truncate">{p.name}</h3>
                  <p className="text-xs text-slate-500 truncate">
                    {p.price ? `${p.price.toLocaleString('fa-IR')} تومان` : 'تماس برای قیمت'}
                  </p>
                </div>

                {/* Reorder */}
                <div className="flex flex-col gap-1">
                  <button
                    onClick={() => moveProduct(idx, 'up')}
                    disabled={idx === 0}
                    className="w-8 h-7 flex items-center justify-center rounded text-slate-400 hover:bg-slate-100 hover:text-brand-600 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
                    aria-label="بالا"
                  >
                    <ArrowUp className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => moveProduct(idx, 'down')}
                    disabled={idx === products.length - 1}
                    className="w-8 h-7 flex items-center justify-center rounded text-slate-400 hover:bg-slate-100 hover:text-brand-600 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
                    aria-label="پایین"
                  >
                    <ArrowDown className="w-4 h-4" />
                  </button>
                </div>

                {/* Actions */}
                <div className="flex gap-1.5">
                  <button
                    onClick={() => openEditForm(p)}
                    className="w-9 h-9 flex items-center justify-center rounded-lg text-slate-600 hover:bg-brand-50 hover:text-brand-600 transition-colors"
                    aria-label="ویرایش"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => handleDelete(p.id)}
                    className="w-9 h-9 flex items-center justify-center rounded-lg text-slate-600 hover:bg-red-50 hover:text-red-500 transition-colors"
                    aria-label="حذف"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Add/Edit Modal */}
      {showForm && (
        <div
          className="fixed inset-0 z-[100] bg-slate-900/50 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in"
          onClick={closeForm}
        >
          <div
            className="bg-white rounded-2xl shadow-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="flex items-center justify-between p-5 border-b border-slate-100 sticky top-0 bg-white rounded-t-2xl z-10">
              <h3 className="text-base font-bold text-slate-800">
                {editingId ? 'ویرایش محصول' : 'افزودن محصول جدید'}
              </h3>
              <button
                onClick={closeForm}
                className="w-8 h-8 flex items-center justify-center rounded-lg text-slate-500 hover:bg-slate-100 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-5 space-y-4">
              {formError && (
                <div className="flex items-center gap-2 px-3 py-2.5 bg-red-50 text-red-600 rounded-lg text-sm">
                  <AlertCircle className="w-4 h-4 flex-shrink-0" />
                  {formError}
                </div>
              )}

              {/* Image preview + upload */}
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">تصویر محصول</label>
                <div className="flex items-center gap-3">
                  <div className="w-20 h-20 rounded-lg overflow-hidden bg-slate-100 flex-shrink-0 border border-slate-200">
                    {form.image ? (
                      <img src={form.image} alt="پیش‌نمایش" className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        <Tag className="w-6 h-6 text-slate-300" />
                      </div>
                    )}
                  </div>
                  <div className="flex-1 space-y-2">
                    <label className="flex items-center justify-center gap-2 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-lg cursor-pointer transition-colors">
                      <Upload className="w-3.5 h-3.5" />
                      آپلود تصویر
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (file) handleImageUpload(file);
                        }}
                      />
                    </label>
                    <input
                      type="text"
                      value={form.image}
                      onChange={(e) => setForm({ ...form, image: e.target.value })}
                      placeholder="یا آدرس تصویر را وارد کنید"
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-transparent"
                      dir="ltr"
                    />
                  </div>
                </div>
              </div>

              {/* Name */}
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1.5">
                  نام محصول <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  placeholder="مثال: آبسردکن مدل KH-101"
                  className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-transparent"
                />
              </div>

              {/* Category */}
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1.5">
                  دسته‌بندی <span className="text-red-500">*</span>
                </label>
                <select
                  value={form.category}
                  onChange={(e) => setForm({ ...form, category: e.target.value })}
                  className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-transparent"
                >
                  {categories.map((c) => (
                    <option key={c.id} value={c.name}>{c.name}</option>
                  ))}
                  <option value="سایر">سایر</option>
                </select>
              </div>

              {/* Short Description */}
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1.5">
                  توضیح کوتاه
                </label>
                <textarea
                  value={form.short_desc}
                  onChange={(e) => setForm({ ...form, short_desc: e.target.value })}
                  placeholder="توضیح مختصری درباره محصول"
                  rows={2}
                  className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-transparent resize-none"
                />
              </div>

              {/* Features */}
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1.5">
                  ویژگی‌های محصول
                </label>
                <p className="text-xs text-slate-400 mb-1.5">هر ویژگی را در یک خط بنویسید</p>
                <textarea
                  value={form.features}
                  onChange={(e) => setForm({ ...form, features: e.target.value })}
                  placeholder={"موتور کم‌صدا\nبدنه استیل ضدزنگ\nگنجایش بالا"}
                  rows={4}
                  className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-transparent resize-none"
                />
              </div>

              {/* Price + Badge */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1.5">
                    قیمت (تومان)
                  </label>
                  <input
                    type="text"
                    value={form.price}
                    onChange={(e) => setForm({ ...form, price: e.target.value })}
                    placeholder="خالی = تماس برای قیمت"
                    className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-transparent"
                    dir="ltr"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1.5">
                    برچسب (اختیاری)
                  </label>
                  <input
                    type="text"
                    value={form.badge}
                    onChange={(e) => setForm({ ...form, badge: e.target.value })}
                    placeholder="مثال: محصول جدید"
                    className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-transparent"
                  />
                </div>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="flex gap-2 p-5 border-t border-slate-100 sticky bottom-0 bg-white rounded-b-2xl">
              <button
                onClick={closeForm}
                className="flex-1 px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-sm font-semibold rounded-lg transition-colors"
              >
                انصراف
              </button>
              <button
                onClick={handleSave}
                disabled={saving}
                className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 bg-brand-600 hover:bg-brand-700 text-white text-sm font-semibold rounded-lg transition-colors disabled:opacity-50"
              >
                {saving ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Save className="w-4 h-4" />
                )}
                {editingId ? 'ذخیره تغییرات' : 'افزودن محصول'}
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
