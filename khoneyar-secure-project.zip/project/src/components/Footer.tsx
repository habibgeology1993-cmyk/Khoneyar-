import { Home, Phone, Smartphone, MapPin, Instagram, Send, MessageCircle, Heart } from 'lucide-react';
import { navLinks, categories, contactInfo } from '@/data/storeData';
import { scrollToSection } from '@/utils/scroll';

export default function Footer() {
  const handleNavClick = (href: string) => {
    scrollToSection(href);
  };

  return (
    <footer className="bg-slate-900 text-slate-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-12 lg:py-16">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8">
          {/* Brand */}
          <div className="col-span-2 lg:col-span-1">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-brand-500 to-brand-700 flex items-center justify-center">
                <Home className="w-5 h-5 text-white" strokeWidth={2.5} />
              </div>
              <div>
                <h3 className="text-lg font-extrabold text-white">خونه یار</h3>
                <p className="text-[10px] text-slate-400">فروشگاه اینترنتی</p>
              </div>
            </div>
            <p className="text-xs sm:text-sm text-slate-400 leading-relaxed mb-4">
              فروشگاه اینترنتی لوازم سرمایشی و گرمایشی و تصفیه آب با هدف ارائه محصولات باکیفیت و خدمات صادقانه.
            </p>
            <div className="flex items-center gap-2">
              <a
                href={`https://instagram.com/${contactInfo.instagram}`}
                target="_blank"
                rel="noopener noreferrer"
                className="w-9 h-9 flex items-center justify-center rounded-lg bg-slate-800 hover:bg-brand-600 transition-colors"
                aria-label="اینستاگرام"
              >
                <Instagram className="w-4 h-4" />
              </a>
              <a
                href={`https://t.me/${contactInfo.telegram}`}
                target="_blank"
                rel="noopener noreferrer"
                className="w-9 h-9 flex items-center justify-center rounded-lg bg-slate-800 hover:bg-brand-600 transition-colors"
                aria-label="تلگرام"
              >
                <Send className="w-4 h-4" />
              </a>
              <a
                href={`https://wa.me/98${contactInfo.mobile.slice(1)}`}
                target="_blank"
                rel="noopener noreferrer"
                className="w-9 h-9 flex items-center justify-center rounded-lg bg-slate-800 hover:bg-brand-600 transition-colors"
                aria-label="واتساپ"
              >
                <MessageCircle className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Links */}
          <div>
            <h4 className="text-sm font-bold text-white mb-4">دسترسی سریع</h4>
            <ul className="space-y-2.5">
              {navLinks.map((link) => (
                <li key={link.href}>
                  <button
                    onClick={() => handleNavClick(link.href)}
                    className="text-xs sm:text-sm text-slate-400 hover:text-brand-400 transition-colors"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Categories */}
          <div>
            <h4 className="text-sm font-bold text-white mb-4">دسته‌بندی محصولات</h4>
            <ul className="space-y-2.5">
              {categories.map((cat) => (
                <li key={cat.id}>
                  <button
                    onClick={() => handleNavClick('#categories')}
                    className="text-xs sm:text-sm text-slate-400 hover:text-brand-400 transition-colors"
                  >
                    {cat.name}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div className="col-span-2 lg:col-span-1">
            <h4 className="text-sm font-bold text-white mb-4">اطلاعات تماس</h4>
            <ul className="space-y-3">
              <li className="flex items-center gap-2 text-xs sm:text-sm text-slate-400">
                <Phone className="w-4 h-4 text-brand-400 flex-shrink-0" />
                <a href={`tel:${contactInfo.phone}`} className="hover:text-brand-400 transition-colors persian-num" dir="ltr">
                  {contactInfo.phone}
                </a>
              </li>
              <li className="flex items-center gap-2 text-xs sm:text-sm text-slate-400">
                <Smartphone className="w-4 h-4 text-brand-400 flex-shrink-0" />
                <a href={`tel:${contactInfo.mobile}`} className="hover:text-brand-400 transition-colors persian-num" dir="ltr">
                  {contactInfo.mobile}
                </a>
              </li>
              <li className="flex items-center gap-2 text-xs sm:text-sm text-slate-400">
                <MapPin className="w-4 h-4 text-brand-400 flex-shrink-0" />
                <span>{contactInfo.address}</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Copyright */}
        <div className="mt-8 sm:mt-10 pt-6 sm:pt-8 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="text-xs text-slate-500 flex items-center gap-1.5">
            تمامی حقوق برای خونه یار محفوظ است.
          </p>
          <p className="text-xs text-slate-500 flex items-center gap-1.5">
            ساخته شده با
            <Heart className="w-3.5 h-3.5 text-brand-500 fill-brand-500" />
            برای خانه شما
          </p>
        </div>
      </div>
    </footer>
  );
}
