# Security setup

## What was fixed in the frontend

- The `#admin` URL is no longer treated as authentication.
- Admin login uses Supabase Auth email/password.
- The UI verifies the signed-in user with `is_admin()` before showing the management panel.
- Product create/update/delete operations are intended to be protected by Supabase RLS.
- Product image uploads are restricted in the UI to JPG/PNG/WebP and 2 MB, with random UUID filenames.
- The admin panel has a sign-out action.

## One-time Supabase setup

1. Create the manager's account in **Authentication → Users**.
2. Copy that user's UUID.
3. Open **SQL Editor** and run `supabase-security.sql`.
4. Replace `USER_UUID` with the manager's UUID and run:

```sql
insert into public.admin_users (user_id) values ('USER_UUID');
```

5. Confirm the `products` table already exists with the fields used by the app.
6. Confirm the `product-images` storage bucket exists (the SQL creates/updates it as public-read).
7. Verify from a non-admin account that product listing works but insert/update/delete and image upload fail.

Do not put a Supabase `service_role` key in the frontend or in `.env` values exposed to Vite. The browser should use only the Supabase URL and anon/publishable key.
