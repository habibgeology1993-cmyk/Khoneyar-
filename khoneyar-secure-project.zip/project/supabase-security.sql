-- Secure the storefront and admin panel.
-- Run this in the Supabase SQL Editor after confirming the `products` table exists.
-- Bootstrap: create the admin account in Supabase Auth, copy its user UUID,
-- then run: insert into public.admin_users (user_id) values ('USER_UUID');

create table if not exists public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

alter table public.admin_users enable row level security;

create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.admin_users
    where user_id = auth.uid()
      and active = true
  );
$$;

revoke all on function public.is_admin() from public;
grant execute on function public.is_admin() to anon, authenticated;

alter table public.products enable row level security;

-- Remove any pre-existing product policies so an older permissive policy cannot bypass the rules below.
do $$
declare
  policy_record record;
begin
  for policy_record in
    select policyname
    from pg_policies
    where schemaname = 'public' and tablename = 'products'
  loop
    execute format('drop policy if exists %I on public.products', policy_record.policyname);
  end loop;
end $$;

drop policy if exists "Public can read products" on public.products;
create policy "Public can read products"
on public.products
for select
to anon, authenticated
using (true);

drop policy if exists "Admins can insert products" on public.products;
create policy "Admins can insert products"
as restrictive
on public.products
for insert
to authenticated
with check (public.is_admin());

drop policy if exists "Admins can update products" on public.products;
create policy "Admins can update products"
as restrictive
on public.products
for update
to authenticated
using (public.is_admin())
with check (public.is_admin());

drop policy if exists "Admins can delete products" on public.products;
create policy "Admins can delete products"
as restrictive
on public.products
for delete
to authenticated
using (public.is_admin());

-- Product images: public read, admin-only writes.
insert into storage.buckets (id, name, public)
values ('product-images', 'product-images', true)
on conflict (id) do update set public = true;

drop policy if exists "Public can read product images" on storage.objects;
create policy "Public can read product images"
on storage.objects
for select
to anon, authenticated
using (bucket_id = 'product-images');

drop policy if exists "Admins can upload product images" on storage.objects;
create policy "Admins can upload product images"
on storage.objects
for insert
to authenticated
with check (
  bucket_id = 'product-images'
  and (storage.foldername(name))[1] = 'products'
  and public.is_admin()
);

drop policy if exists "Admins can update product images" on storage.objects;
create policy "Admins can update product images"
on storage.objects
for update
to authenticated
using (bucket_id = 'product-images' and public.is_admin())
with check (
  bucket_id = 'product-images'
  and (storage.foldername(name))[1] = 'products'
  and public.is_admin()
);

drop policy if exists "Admins can delete product images" on storage.objects;
create policy "Admins can delete product images"
on storage.objects
for delete
to authenticated
using (bucket_id = 'product-images' and public.is_admin());
-- These restrictive guards make the bucket write rules safe even if another
-- permissive storage policy exists elsewhere in the project.
drop policy if exists "Only admins may write product images" on storage.objects;
create policy "Only admins may write product images"
as restrictive
on storage.objects
for all
to authenticated
using (bucket_id <> 'product-images' or public.is_admin())
with check (bucket_id <> 'product-images' or public.is_admin());

